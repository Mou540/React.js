import React from 'react'
import Reducer from './Reducer' 
import Reducer1 from './Reducer1'
import UseMemo from './UseMemo'
import Parent from './Callback'
import CounterApp from './CounterApp'

function App() {
  return (
    <div>
      <Reducer/>
      <Reducer1/>
      <UseMemo/>
      <Parent/>
      <CounterApp/>
    </div>
  )
}

export default App
