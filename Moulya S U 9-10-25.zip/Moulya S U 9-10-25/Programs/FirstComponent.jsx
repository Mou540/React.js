import React from 'react'

function FirstComponent(moulya) {
  return (
    <div>
      <h1>FirstComponent {moulya.name}</h1>
      <SecondComponent phno="7026352866"/>
    </div>
  )
}

function SecondComponent(moulya1) {
  return (
    <div>
      SecondComponent {moulya1.phno}
    </div>
  )
}

export default FirstComponent
