import React from 'react'
import FirstComponent from './FirstComponent'
import Fruit from './ClassOne'
import Parent from './PropsChildern'

function App() {
  return (
    <div>
      <FirstComponent name="Moulya" />
      <FirstComponent name="Moulya" />
      <FirstComponent name="Moulya" />
      <Fruit/>
      <Parent/>
    </div>
  )
}

export default App;
