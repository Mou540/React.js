import { useState } from 'react'
import './App.css'
/* import Hooks from './hooks'
import Counter from './Counter'
import Cleanup from './Cleanup'
import UsersList from './UsersList'
import { Greeting } from './Css'
import { Temperature } from './Css' */
import External from './External'
import Button from './Button'
import StyledComponents from './StyledComponents'

function App() {
  return (
      <div>
        {/* <Hooks/>
        <Counter/>
        <Cleanup/> 
        <UsersList/>
        <Greeting/>
        <Temperature/> */}
        <External/>
        <Button/>
        <StyledComponents/>
      </div>
      
  )
}

export default App
