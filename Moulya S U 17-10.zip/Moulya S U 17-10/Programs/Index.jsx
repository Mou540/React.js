import React from 'react'
import {Link} from 'react-router-dom'

function Index() {
  return (
    <div>
      <h1>This is the Index Page </h1>
      <nav>
        <Link to='/home'>HomePage ||</Link>
        <Link to='/about'>AboutUS ||</Link>
        <Link to='/contact'>ContactUS</Link>
        </nav>
    </div>
  )
}

export default Index
