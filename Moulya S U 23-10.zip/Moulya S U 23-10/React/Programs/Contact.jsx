import React, { useRef, useContext } from 'react';
import { ThemeContext } from './ThemeContext';

const Contact = () => {
  const { theme } = useContext(ThemeContext);
  const inputRef = useRef(null);

  const focusInput = () => {
    inputRef.current.focus();
    alert('Input focused!');
  };

  const inputStyle = {
    padding: '10px',
    width: '80%',
    maxWidth: '300px',
    marginRight: '10px',
    borderRadius: '5px',
    border: `1px solid ${theme === 'light' ? '#333' : '#fff'}`,
    backgroundColor: theme === 'light' ? '#fff' : '#555',
    color: theme === 'light' ? '#000' : '#fff',
    outline: 'none'
  };

  const buttonStyle = {
    padding: '10px 20px',
    borderRadius: '5px',
    border: 'none',
    cursor: 'pointer',
    backgroundColor: theme === 'light' ? '#333' : '#f5f5f5',
    color: theme === 'light' ? '#fff' : '#000',
    transition: 'all 0.3s ease'
  };

  return (
    <div style={{ textAlign: 'center', marginTop: '20px' }}>
      <input
        ref={inputRef}
        type="text"
        placeholder="Your Email"
        style={inputStyle}
      />
      <button style={buttonStyle} onClick={focusInput}>
        Focus Input
      </button>
    </div>
  );
};

export default Contact;
