import React from 'react';
import { ThemeProvider } from './ThemeContext';
import Portfolio from './Portfolio';
import ThemeToggle from './ThemeToggle';
import Contact from './Contact';

const App = () => {
  const appStyle = {
    fontFamily: 'Arial, sans-serif',
    minHeight: '100vh',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center'
  };

  return (
    <ThemeProvider>
      <div style={appStyle}>
        <Portfolio />
        <ThemeToggle />
        <Contact />
      </div>
    </ThemeProvider>
  );
};

export default App;


