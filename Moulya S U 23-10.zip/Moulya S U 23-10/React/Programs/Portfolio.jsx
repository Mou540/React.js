import React, { useContext } from 'react';
import { ThemeContext } from './ThemeContext';

const Portfolio = () => {
  const { theme } = useContext(ThemeContext);

  const styles = {
    container: {
      padding: '20px',
      borderRadius: '10px',
      textAlign: 'center',
      margin: '20px auto',
      width: '80%',
      maxWidth: '500px',
      color: theme === 'light' ? '#000' : '#fff',
      backgroundColor: theme === 'light' ? '#f5f5f5' : '#333',
      transition: 'all 0.3s ease'
    },
    img: {
      width: '120px',
      height: '120px',
      borderRadius: '50%',
      marginBottom: '15px'
    },
    name: { fontSize: '2rem', fontWeight: 'bold' },
    role: { fontSize: '1.2rem', margin: '5px 0' },
    about: { fontSize: '1rem' }
  };

  return (
    <div style={styles.container}>
      <img
        style={styles.img}
        src="src/Image.jpeg"
        alt="Profile"
      />
      <div style={styles.name}>Moulya S U</div>
      <div style={styles.role}>Front-End Developer</div>
      <div style={styles.about}>
        I build responsive web applications using React and enjoy learning new
        technologies.
      </div>
      <div style={{ marginTop: '10px', fontStyle: 'italic' }}>
        Current Theme: {theme.charAt(0).toUpperCase() + theme.slice(1)}
      </div>
    </div>
  );
};

export default Portfolio;
