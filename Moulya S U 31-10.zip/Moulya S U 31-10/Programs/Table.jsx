import React from 'react';

function Table() {
  const firstRowStyle = {
    backgroundColor: "red",
    color: "white"
  };

  const secondRowStyle = {
    backgroundColor: "green",
    color: "white"
  };

  const cellStyle = {
    padding: "8px",
    textAlign: "left"
  };

  return (
    <table border="1" cellPadding="5" cellSpacing="0">
      <tbody>
        <tr style={firstRowStyle}>
          <td style={cellStyle}>Moulya</td>
          <td style={cellStyle}>React Developer</td>
        </tr>
        <tr style={secondRowStyle}>
          <td style={cellStyle}>Megha</td>
          <td style={cellStyle}>React Developer</td>
        </tr>
      </tbody>
    </table>
  );
}

export default Table;
