import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import hello from './helloWold'

function App() {
  
  return(
    <>
    <h1>Hello World</h1>
    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Magni earum voluptas dolor tempora doloremque officia nihil optio. Sapiente aut, omnis in, veritatis, commodi quia odit cumque corrupti officiis molestiae odio.</p>
    <hello />
    </>
  )
}

export default App
