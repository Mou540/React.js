import React, { useState } from 'react'
function SimpleValidation(){
    const [email,setEmail]=useState("");
    const [error,setError]=useState("");
    const [number,setNum]=useState("");
    const [errorr,setError2]=useState("");
    const handleSubmit=(e)=>{
        e.preventDefault();
        if(!email.includes("@")){
            setError("Please enter a valid email!");
        }else{
            setError("");
            alert(`Email Submitted:${email}`);
        }
        if(!number.length>=10 && number.length<10){
            setError2("Please enter a valid Number!");
        }else{
            setError2("");
            alert(`Number Submitted:${number}`);
        }
    };
    return(
        <form onSubmit={handleSubmit}>
            <input type="email" value={email} onChange={(e)=>setEmail(e.target.value)}
            />
            <input type="number" value={number} onChange={(e)=>setNum(e.target.value)}/>
            {error && <p style={{color:"red"}}>{errorr}</p>}
            <button type="submit">Submit</button>
            {error && <p style={{color:"red"}}>{error}</p>}
        </form>
    );
}
export default SimpleValidation